import { Component, OnInit } from '@angular/core';
import {Http, Response, Headers} from '@angular/http';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private http:Http) { }
  confirmationString:String = "New Employee has been added";
  isAdded:boolean=false;
  productObj:object={};
  addNewProduct=function(product){
    this.productObj = {
      "firstName": product.firstName,
      "lastName": product.lastName,
      "age":product.age,
      "empId":product.empId,
      "city":product.city

    }
    this.http.post("http://localhost:5555/employees",this.productObj).subscribe(
      (res:Response)=>{this.isAdded=true;}
    )
  }


  ngOnInit(): void {
  }

}
