import React from "react";
import { View, StyleSheet, Card } from "react-native";

const TodoCard = (note) => {
    return (
        <Card style={{margin:10}}>
            <p>{note}</p> 
            {/* <Text>{note}</Text> */}
        </Card>);
}

export default TodoCard;