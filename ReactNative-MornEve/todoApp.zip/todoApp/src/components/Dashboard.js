import React, { useEffect, useState } from 'react';
import { Text, TextInput, View, Button, SafeAreaView, Platform, StyleSheet, ActivityIndicator, FlatList, AsyncStorage, Appbar } from 'react-native';
import TodoCard from "./TodoCard";
import Login from "./Login";

export default function Dashboard({navigation, props}) {
    const [note, setNote] = useState([]);
    const username = this.props.navigation.getParam(username, "");

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        const noteList = await AsyncStorage.getItem("note");
        if(noteList != "")
            setNote(noteList);
    }

    // const renderNote = () => {
    //     if (note != "") {
    //         return (<view > <FlatList
    //             data={note}
    //             renderItem={({ item }) => <TodoCard data={item} navigation={this.props.navigation} />}
    //             keyExtractor={(item) => item}
    //             initialNumToRender={8} >
    //             <Text style={styles.todoText}>{note}</Text> 
    //             <Button title="Delete" value={note} onPress={handleDelete} style={styles.deleteButton} /> 
    //         </FlatList> </view>)
    //     }
    //     return <ActivityIndicator size="large" />
    // }

    const handleDelete = async (item) => {
        try {
            const arrNote = await AsyncStorage.getItem('note');
            const arr = JSON.parse(arrNote);
            const cnt = arrNote.indexOf(item);
            await AsyncStorage.removeItem(cnt);
            await AsyncStorage.setItem('note', JSON.stringify(arr));
            this.useEffect();
        } catch (error) {
            console.log(error);
        }
    };

    const logout = async () => {
        await AsyncStorage.removeItem(username);
        navigation.navigate("Login");
    }

    const addTodo = async () => {
        const arrNote = await AsyncStorage.getItem('note') || "";
        arrNote.push(note);
        await AsyncStorage.setItem("note", JSON.stringify(note));
        this.useEffect();
    };

    return (
        <SafeAreaView style={styles.mainContainer}>
            <Button style={{margin: 10}} onPress={logout}>
                Logout {username}
            </Button>
            
            <TextInput
                style={styles.inputForm}
                onChangeText={(note) => setNote(note)}
                placeholder="Write your todo" />
            <Button title="Add" mode="contained" style={{margin: 10}} onPress={addTodo} />

            <Text style={styles.todoText}>{note}</Text> 
            <Button title="Delete" value={note} onPress={handleDelete} style={styles.deleteButton} />
        </SafeAreaView>
    );
}


const styles = StyleSheet.create({
    mainContainer: {
        marginTop: Platform.OS === 'android' ? 25 : 0
    }
})