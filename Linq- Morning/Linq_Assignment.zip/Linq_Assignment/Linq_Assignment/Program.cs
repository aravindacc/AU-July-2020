﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Linq_Assignment
{

    class Dancer
    {
        public string Fname { get; set; }
        public string Lname { get; set; }
        public int ID { get; set; }
    }

    class Singer
    {
        public string Fname { get; set; }
        public string Lname { get; set; }
        public int ID { get; set; }
    }



    class Program
    {
        
        void ques1()
        {
            var vowels = new HashSet<char> { 'a', 'e', 'i', 'o', 'u' };

            Console.Write("Enter a Sentence : ");
            string word = Console.ReadLine().ToLower();

            int total = word.Count(c => vowels.Contains(c));
            Console.WriteLine(" ");
            Console.WriteLine("Total number of vowels in the sentence are : {0}", total);
            Console.ReadLine();
        }
        void ques3()
        {     // Create a list of dancers
            List<Dancer> Dancers = new List<Dancer> {
                new Dancer { Fname = "Terrance", Lname = "Louis", ID = 522459 },
              
                 new Dancer { Fname = "Geeta", Lname = "Kapoor", ID = 866200 },
                 new Dancer { Fname = "Remo", Lname = "Dsouza", ID = 204467} };

            // Create a list of Singers
            List<Singer> Singers = new List<Singer> {
                new Singer {  Fname = "Remo", Lname = "Dsouza", ID = 204467},
                new Singer { Fname = "Geeta", Lname = "Kapoor", ID = 204467},
                new Singer { Fname = "Jerry", Lname = "Tom", ID = 9913 } };

            // Join the two data sources based on a composite key consisting of first and last name,
            // to determine which Dancer is also a Singer.
            IEnumerable<string> query = from Dancer in Dancers
                                        join Singer in Singers
                                        on new { Dancer.Fname, Dancer.Lname }
                                        equals new { Singer.Fname, Singer.Lname }
                                        select Dancer.Fname + " " + Dancer.Lname;

            Console.WriteLine("The following people are both dancer and singer:");
            foreach (string name in query)
                Console.WriteLine(name);
        }

    

    void ques2()
        {
            String[] StudentNames = { "Kavita", "Avani", "Amit", "Neetu" };
            var res = from s in StudentNames
                      where s.Contains("ee")
                      select s;

            foreach (var q in res)
            {
                Console.WriteLine(q);
            }
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.ques2();
        }


    }

}
