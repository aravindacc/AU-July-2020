# newsapp-rn

- Clone the repo
- cd newsapp-rn
- npm install
- npm run android / npm run ios / npm start
