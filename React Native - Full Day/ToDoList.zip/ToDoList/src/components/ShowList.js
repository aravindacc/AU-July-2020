import React from "react";
import { ImageBackground, Text, View, TouchableOpacity, StyleSheet } from "react-native";

const ShowList = (data) => {
    return (
        <View>
                    
                        
                    <Text>{data}</Text>
                    
                </View>
    );
}


export default ShowList;
