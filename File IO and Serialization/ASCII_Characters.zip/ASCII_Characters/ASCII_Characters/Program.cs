﻿using System;
using System.IO;


namespace ASCII_Characters
{
    class Program
    {
        static void Main()
        {
          

            if (!File.Exists(@"C:\Users\Kavita Goodwani\source\repos\sample.txt"))
            {
                Console.WriteLine("Not found {0}");
                return;
            }


            try
            {
                FileStream file = File.OpenRead(@"C:\Users\Kavita Goodwani\source\repos\sample.txt");
                byte[] data = new byte[file.Length];
                file.Read(data, 0, (int)file.Length);
                file.Close();

                StreamWriter newFile = new StreamWriter(@"C:\Users\Kavita Goodwani\source\repos\sample2.data");
                for (int i = 0; i < data.Length; i++)
                {
                    if (((Convert.ToInt32(data[i]) >= 32) &&
                    (Convert.ToInt32(data[i]) <= 127)) ||
                    (Convert.ToInt32(data[i]) == 10) ||
                    (Convert.ToInt32(data[i]) == 13))
                    {
                        newFile.Write(Convert.ToChar(data[i]));
                    }

                }
                Console.WriteLine("Binary File Created");
                newFile.Close();
            }
            catch (Exception)
            {
                Console.WriteLine("Error");
            }
        }
    }

}
