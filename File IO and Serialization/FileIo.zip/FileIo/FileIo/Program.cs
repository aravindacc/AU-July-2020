﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace FileIo
{
   

   public class Program
        {
            public static void Main()
            {
                string dir = @"C:/Users/Kavita Goodwani/Desktop/File";
                // If directory does not exist, create it
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                string fileName = @"C:/Users/Kavita Goodwani/Desktop/File/read.txt";

                try
                {


                    // Create a new file     
                    using (StreamWriter sw = File.CreateText(fileName))
                    {
                        sw.WriteLine("New file created: {0}", DateTime.Now.ToString());
                        sw.WriteLine("File I/O Assignment created by Kavita Goodwani");
                        sw.WriteLine("Done! Thank You");
                    }

                    // Write file contents on console.     
                    var numberOfCharacters = File.ReadAllLines(@"C:/Users/Kavita Goodwani/Desktop/File/read.txt").Sum(s => s.Length);
                    Console.WriteLine(numberOfCharacters);

                    try
                    {
                        Stack<string> myStack = new Stack<string>();
                        int count = 0;
                        using (StreamReader sr = new StreamReader(@"C:/Users/Kavita Goodwani/Desktop/File/read.txt"))
                        {
                            string line;

                            while ((line = sr.ReadLine()) != null)
                            {
                                myStack.Push(line);
                                count++;
                            }
                        }
                        using (StreamWriter sw1 = File.CreateText(@"C:/Users/Kavita Goodwani/Desktop/File/write.txt"))
                        {
                            while (count > 0)
                            {
                                string l = myStack.Pop();
                                sw1.WriteLine(l);
                                count--;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        // Let the user know what went wrong.
                        Console.WriteLine("The file could not be read:");
                        Console.WriteLine(e.Message);
                    }

                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.ToString());
                }
            }
        }
    }
