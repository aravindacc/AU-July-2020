/**
 * StudentServiceImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.soap.accolite.service.impl;

public interface StudentServiceImplService extends javax.xml.rpc.Service {
    public java.lang.String getStudentServiceImplAddress();

    public com.soap.accolite.service.impl.StudentServiceImpl getStudentServiceImpl() throws javax.xml.rpc.ServiceException;

    public com.soap.accolite.service.impl.StudentServiceImpl getStudentServiceImpl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
