import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatasetService {

  constructor() {
    let data1 =
    {
      Fname: 'Kavita',
      Lname: 'Goodwani',
      age: 22,
      Empid: 438,
      city: 'Delhi'
    };
    let data2 = {
      Fname: 'Deepak',
      Lname: 'Goswami',
      age: 23,
      Empid: 432,
      city: 'Haryana'
    };

    sessionStorage.setItem('438', JSON.stringify(data1));
    sessionStorage.setItem('432', JSON.stringify(data2));
  }
  getitem(key: string) {
    let data = sessionStorage.getItem(key);
    return JSON.parse(data);
  }
  getAllitem() {
    let tabledata = [];
    for (let x = 0; x < sessionStorage.length; x++) {
      tabledata.push(JSON.parse(sessionStorage[sessionStorage.key(x)]));
    }
    return tabledata;
  }
  additem(key: string, data) {
    sessionStorage.setItem(key, JSON.stringify(data));
  }
  updateitem(key: string, data) {
    this.additem(key, data);
  }

  removeitem(key: string) {

    sessionStorage.removeItem(key);
  }
}
