import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-child',
  templateUrl: './resource-child.component.html',
  styleUrls: ['./resource-child.component.scss']
})
export class ResourceChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
