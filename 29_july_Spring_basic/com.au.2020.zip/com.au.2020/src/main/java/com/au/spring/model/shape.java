package com.au.spring.model;

public interface shape {
	public void getType();
	public double area();
}
