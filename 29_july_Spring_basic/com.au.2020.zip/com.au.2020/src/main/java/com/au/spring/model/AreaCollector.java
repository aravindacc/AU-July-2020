package com.au.spring.model;

public class AreaCollector {
	public void getArea(shape obj)
	{
		System.out.println("Area : "+obj.area());
	}
}
