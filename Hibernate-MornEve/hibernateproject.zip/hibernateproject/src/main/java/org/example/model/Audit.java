package org.example.model;

import com.sun.istack.NotNull;
import javax.persistence.*;

@Entity
@Table(name = "AU_Audit")
public class Audit {
    @Id
    @GeneratedValue
    private Integer txnId;
    @NotNull
    @ManyToOne
    private Account txnSender;
    @NotNull
    @ManyToOne
    private Account txnReceiver;
    @NotNull
    private Integer amount;

    public Account getTxnSender() {
        return txnSender;
    }

    public void setTxnSender(Account txnSender) {
        this.txnSender = txnSender;
    }

    public Account getTxnReceiver() {
        return txnReceiver;
    }

    public void setTxnReceiver(Account txnReceiver) {
        this.txnReceiver = txnReceiver;
    }

    public Integer getTxnId() {
        return txnId;
    }

    public void setTxnId(Integer txnId) {
        this.txnId = txnId;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

}
