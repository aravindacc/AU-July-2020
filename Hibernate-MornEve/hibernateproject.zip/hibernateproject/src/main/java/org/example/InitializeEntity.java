package org.example;

import org.example.model.Account;
import org.example.model.Audit;
import org.example.model.User;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class InitializeEntity {

    public void initializeEntity(Session session, Account a1, Account a2, Account a3){
        //users
        User u1 = new User();
        u1.setUserId(1);
        u1.setUserName("Jay");

        User u2 = new User();
        u2.setUserId(2);
        u2.setUserName("Uday");

        //accounts
        a1.setAccountId(11);
        a1.setAmount(1000);
        a1.setAccountUser(u1); //user1

        a2.setAccountId(22);
        a2.setAmount(800);
        a2.setAccountUser(u2); //user2

        a3.setAccountId(33);
        a3.setAmount(1000);
        a3.setAccountUser(u2); //user3

        Transaction transaction1 = session.beginTransaction();

        session.save(u1);
        session.save(u2);
        session.save(a1);
        session.save(a2);
        session.save(a3);

        transaction1.commit();
        System.out.println("Entity Initialized.");

    }

}
