package org.example;

import org.example.model.Account;
import org.example.model.Audit;
import org.example.model.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.io.File;

public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );

        Configuration config = new Configuration().configure(new
                File("src/main/java/org/example/hibernate.cfg.xml"))
                .addAnnotatedClass(User.class).addAnnotatedClass(Account.class)
                .addAnnotatedClass(Audit.class);

        SessionFactory sessionFactory = config.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Account a1 = new Account();
        Account a2 = new Account();
        Account a3 = new Account();
        Account a4 = new Account();

        //for initialization of the objects
        InitializeEntity ie = new InitializeEntity();
        ie.initializeEntity(session, a1, a2, a3);

        //txn operations
        AmountTxnOperation ato1 = new AmountTxnOperation();
        ato1.auditTxn(500, a1, a2, session); //within diff users
        ato1.auditTxn(400, a2, a3, session); //same user

        ato1.auditTxn(1500, a2, a3, session); //failed txn
        ato1.auditTxn(100, a3, a4, session); //failed txn. Wrong acc no.

        session.close();
        System.out.println("end App");

    }
}
