package org.example.model;

import javax.persistence.*;

@Entity
@Table(name = "AU_Account")
public class Account {
    @Id
    private Integer accountId;
    @Column(nullable = false)
    private Integer amount;

    @ManyToOne
    private User accountUser;

    public User getAccountUser() {
        return accountUser;
    }

    public void setAccountUser(User accountUser) {
        this.accountUser = accountUser;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }
}
