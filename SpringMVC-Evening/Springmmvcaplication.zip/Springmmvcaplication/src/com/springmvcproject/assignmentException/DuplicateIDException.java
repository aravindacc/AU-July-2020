package com.springmvcproject.assignmentException;

public class DuplicateIDException extends Exception {

	public DuplicateIDException(String errorMessage) {
        super(errorMessage);
    }
	

}
