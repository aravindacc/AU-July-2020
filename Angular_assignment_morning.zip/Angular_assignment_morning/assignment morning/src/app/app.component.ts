import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  
  title = "Angular Morning Assingment";

   supermarket: any={} =[
    {
      id: 1,
      title: "Bread"
    },
    {
      id:2,
      title:"Butter"
    },
    {
      id: 3,
      title: "Milk"
    },
    {
      id:4,
      title:"Fruits"
    },
    {
      id: 5,
      title: "Chocolates"
    },
    {
      id:6,
      title:"Perfume"
    },
    {
      id: 7,
      title: "Bottles"
    },
    {
      id:8,
      title:"Suits"
    },
    {
      id: 9,
      title: "Jeans"
    },
    {
      id:10,
      title:"Shorts"
    },
    {
      id: 11,
      title: "Eyeglass"
    },
    {
      id:12,
      title:"Vegetables"
    },
    {
      id:13,
      title:"Dry Fruits"
    },
    {
      id:14,
      title:"Bags"
    }
    
  ]

  ngOnInit():void{
    console.log("app class")
  }
  
}
