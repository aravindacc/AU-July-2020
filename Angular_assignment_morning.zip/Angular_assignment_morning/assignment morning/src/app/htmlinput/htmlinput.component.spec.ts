import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtmlinputComponent } from './htmlinput.component';

describe('HtmlinputComponent', () => {
  let component: HtmlinputComponent;
  let fixture: ComponentFixture<HtmlinputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtmlinputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtmlinputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
