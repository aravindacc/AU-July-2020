import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-htmlinput',
  templateUrl: './htmlinput.component.html',
  styleUrls: ['./htmlinput.component.scss']
})
export class HtmlinputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
