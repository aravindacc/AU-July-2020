﻿using System;


namespace Multicast_Delegates
{
    class MultiCast
    {
       
        public delegate void myDelegate(string a, string b);
        private string value;
        public void Function(string a, string b)
        {
            if (a.Length > b.Length)
                value = value + a + b;
            else
                value = value + b + a;
        }
           public void Function2(string a, string b)
        {
            if (a.Length > b.Length)
                value = value + a;
            else
                value = value + b;

        }
   
        public void Call()
        {
            string input_1, input_2;
            myDelegate obj;
            //Multicasting the Delegate obj
            obj = Function;
            obj += Function2;
            Console.WriteLine("Enter String 1:");
            input_1 = Console.ReadLine();
            Console.WriteLine("Enter String 2:");
            input_2 = Console.ReadLine();
            obj(input_1, input_2);
            Console.WriteLine("Value of string : " + value);
        }


        static void Main(string[] args)
        {
            MultiCast obj2 = new MultiCast();
            obj2.Call(); //Calling multicasted function

        }
    }
}