﻿using System;
using System.IO;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace Sum_Event
{
    public class ProcessEventArgs : EventArgs
    {
        public int num1 { get; set; }
        public int num2 { get; set; }
    }

    public class Event_Handler
    {
        // declaring an event using built-in EventHandler
        public event EventHandler<ProcessEventArgs> ProcessCompleted;


        public void StartProcess()
        {
            var data = new ProcessEventArgs();

            try
            {
                Console.WriteLine("Enter first number:");
                String n1 = Console.ReadLine();
                Console.WriteLine("Enter second number:");
                String n2 = Console.ReadLine();
                data.num1 = Convert.ToInt32(n1); // Input coming from console is a string so conversion to int is required
                data.num2 = Convert.ToInt32(n2);
                Console.WriteLine("Press Enter to add");
                ConsoleKeyInfo keyinfo;
                keyinfo = Console.ReadKey();
                if (keyinfo.Key == ConsoleKey.Enter) // Evaluating if enter key is pressed
                {
                    OnProcessCompleted(data);
                }
                else
                {
                    Console.WriteLine("Press Enter Key to perform the given operation !!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Caught {0} !!!", ex);
            }
        }


        protected virtual void OnProcessCompleted(ProcessEventArgs e)
        {
            ProcessCompleted?.Invoke(this, e);
        }

    }

    class Program
    {
        public static void Main()
        {
            Event_Handler bl = new Event_Handler();
            bl.ProcessCompleted += bl_ProcessCompleted; // register with an event
            bl.StartProcess();
        }

        
        public static void bl_ProcessCompleted(object sender, ProcessEventArgs e)
        {
            Console.WriteLine(e.num1 + e.num2); // performing required operation
        }

    }

}
