﻿using System;

namespace Generics
{
   
    class myStack<T>
    {
        int size;
        T[] a;
        int index;
        //Constructor
        public myStack(int size)
        {
            this.size = size;
            a = new T[size];
            index = -1;
        }
     
        public void push(T x)
        {
            if (index < size - 1)
            {
                a[++index] = x;
            }
            else
            {
                Console.WriteLine("Stack is Full");
            }
        }
       
        public T pop()
        {
            if (index == -1)
            {
                 Console.WriteLine("Stack is empty");
                return default(T);
            }
            else
            {
                index--;
                return a[index + 1];
            }
        }
    
        public T top()
        {
            if (index == -1)
            {
                Console.WriteLine("Stack is empty");
                return default(T);
            }
            else
            {
                return a[index];
            }
        }
    
        public Boolean isEmpty()
        {
            if (index == -1)
                return true;
            return false;
        }

    }


    //A Generic Queue Class of Given Size
    class myQueue<T>
    {
        int size;
        T[] a;
        int front, rear;
        //Constructor
        public myQueue(int size)
        {
            this.size = size;
            a = new T[size];
            front = rear = -1;
        }
        //Function to add an element to the rear of the queue
        public void enqueue(T x)
        {
            if (front == -1)
            {
                front++;
                rear++;
                a[rear] = x;
            }

            else if (rear == size - 1)
            {
                Console.WriteLine("Queue is Full");
            }
            else
            {
                rear++;
                a[rear] = x;

            }
        }
          public T dequeue()
        {
            if (front == rear)
            {
                T temp = a[front];
                front = rear = -1;
                return temp;
            }
            else if (front == -1)
            {
                //In case if Queue is empty, a message is displayed to the user and the default value is returned
                Console.WriteLine("Queue is Empty");
                return default(T);
            }
            else
            {
                front++;
                return a[front - 1];
            }
        }
        //Function that returns the element at the front of the queue
        public T top()
        {
            if (front == -1)
            {
                //In case if Queue is empty, a message is displayed to the user and the default value is returned          
                Console.WriteLine("Queue is Empty");
                return default(T);
            }
            else
            {
                return a[front];
            }
        }
        //Function which returns true if the queue is empty
        public Boolean isEmpty()
        {
            if (front == -1)
                return true;
            return false;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            //Creating objects of different data types using Generic Classes
            //Values have been hard-coded for easy demonstration

            myStack<int> obj2 = new myStack<int>(3);
            Console.WriteLine("Stack Size: 3");
            Console.WriteLine("Elements being pushed into the stack: 1,2,3");
            obj2.push(1);
            obj2.push(2);
            obj2.push(3);
            Console.WriteLine("Top Element:" + obj2.top());
            Console.WriteLine("Element Popped:" + obj2.pop());
            Console.WriteLine("Top Element: " + obj2.top());
            Console.WriteLine("Element Popped:" + obj2.pop());
            Console.WriteLine("Top Element: " + obj2.top());
            Console.WriteLine("Element Popped:" + obj2.pop());
            Console.WriteLine("Is Stack Empty:" + obj2.isEmpty());


            Console.WriteLine("--------------------------------------");

            myQueue<string> obj4 = new myQueue<string>(4);
            Console.WriteLine("Queue Size: 4");
            obj4.enqueue("Generics");
            obj4.enqueue("Assignment");
            obj4.enqueue("By");
            obj4.enqueue("Kavita");
            obj4.enqueue("Goodwani");

            Console.WriteLine("Front Element:" + obj4.top());
            Console.WriteLine("Element Removed:" + obj4.dequeue());
            Console.WriteLine("Front Element: " + obj4.top());
            Console.WriteLine("Element Removed:" + obj4.dequeue());
            Console.WriteLine("Front Element: " + obj4.top());
            Console.WriteLine("Element Removed:" + obj4.dequeue());
            Console.WriteLine("Front Element: " + obj4.top());
            Console.WriteLine("Element Removed:" + obj4.dequeue());
            Console.WriteLine("Is Queue Empty:" + obj4.isEmpty());



        }
    }

}