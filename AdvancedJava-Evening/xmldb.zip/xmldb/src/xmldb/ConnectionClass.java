package xmldb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass {
	private static final String url = "jdbc:mysql://localhost:3306/studentData";
	private static final String user = "root";
	private static final String password = "4321"; 
	private static Connection con;

	public Connection getConnection() {

		try { 
			con = DriverManager.getConnection(url, user, password);
			System.out.println("success"+ con);

		} catch (SQLException sqlEx) {
			sqlEx.printStackTrace();
		}
		return con;
	}
}
