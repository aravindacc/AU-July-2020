package xmldb;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class Xmldb {
    private static boolean exists;
    static ConnectionClass connectionClass = new ConnectionClass();
    static Connection conn = connectionClass.getConnection();
    static NodeList nlist, nlist1;

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
        if(!exists) {
            createTable();
            System.out.println("Table created ");
            exists=true;
        }
        else {
            System.out.println("Table Already exists ");
        }

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        File file = new File("input.txt");
        Document xmlDoc = builder.parse(file);
        xmlDoc.getDocumentElement().normalize();
        NodeList nlist1 = xmlDoc.getElementsByTagName("/class/student");

        for (int i = 0 ; i < nlist1.getLength() ; i++) {
            Node node = nlist1.item(i);
            Node nameNode= nlist1.item(i);
            int rollno = Integer.parseInt(getAttrValue(node, "rollno"));
            String fname = getTextContent(nameNode, "firstname")+" "+getTextContent(nameNode, "middlename");
            String lname = getTextContent(nameNode, "lastname");
            String gender = getTextContent(node, "gender");
            String marks = getTextContent(node, "marks");
            
            addRow(rollno, fname, lname, gender, marks,conn);  
        }
    }
    
    static private String getAttrValue(Node node,String attrName) {
        if ( ! node.hasAttributes() ) return "";
        NamedNodeMap nmap = node.getAttributes();
        if ( nmap == null ) return "";
        Node n = nmap.getNamedItem(attrName);
        if ( n == null ) return "";
        return n.getNodeValue();
    }
    
    static private String getTextContent(Node parentNode,String childName) {
        nlist = parentNode.getChildNodes();
        for (int i = 0 ; i < nlist.getLength() ; i++) {
            Node n = nlist.item(i);
            String name = n.getNodeName();
            if ( name != null && name.equals(childName) )
                return n.getTextContent();
        }
        return "";
    }
	
    private static void createTable() {
        try {
            conn.createStatement().execute("CREATE  TABLE student (" + 
                " id INT NOT NULL ," + 
                " name VARCHAR(45) NULL ," + 
                " surname VARCHAR(45) NULL ," +
                " gender VARCHAR(10) NULL, "+
                " marks FLOAT NULL, " +
                " PRIMARY KEY (`id`) );");
        } catch (SQLException e) {
            System.out.println("Table Already Exists, Skipping...");
        }
    }
    
    public static void addRow(int rollno, String fname, String lname, String gender, String marks, Connection conn) {
        try {
            PreparedStatement stmt = conn.prepareStatement("insert into Student values (?,?,?,?,?)");
            stmt.setInt(1, rollno);
            stmt.setString(2, fname);
            stmt.setString(3, lname);
            stmt.setString(4, gender);
            stmt.setString(5, marks);
            stmt.execute();
        } catch (Exception e) {
           System.out.println(e.getMessage());
        }
    }
}
