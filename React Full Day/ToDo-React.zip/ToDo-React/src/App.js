import React from 'react';
import logo from './logo.svg';
import './App.css';
import ToDolist from './ToDolist'
function App() {
  return (
    <ToDolist ></ToDolist>
  );
}

export default App;
