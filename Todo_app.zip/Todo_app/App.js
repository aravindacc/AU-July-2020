import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import Main from './app/components/Main';
import Login from './app/components/Login';

const Stack = createStackNavigator();
export default class App extends React.Component{
  render(){
    return(
      <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="To-Do"  component={Main} />
      </Stack.Navigator>
    </NavigationContainer>

      // <Login />
      // <Main />
    );
  }
}
