import { Component,EventEmitter } from '@angular/core';
import { FunService} from './fun.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private checkService: FunService) {}
  title = 'information';
  dis = 'true';
  objects= [
    {id:1,employee : 'aman'},
    {id:2,employee: 'shubham'},
    {id:3,employee : 'ashish'},
    {id:4,employee : 'himanshu'}
  ]

}